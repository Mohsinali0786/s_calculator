pub fn cal(num1:u8,num2:u8)->u8
{
    let num1=5;
    let num2=3;
    let num3=num1+num2;
    num3
}
